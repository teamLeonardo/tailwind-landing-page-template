// mi_pagina_content_script.js
console.log("script de la pagina 2");
window.addEventListener('message', (event) => {
    // Asegúrate de que el mensaje provenga de tu página web
    if (event.source !== window) return;
    // Verifica la estructura del mensaje
    console.log("event.data mi_pagina_content_script ==>", event.data);
    if (event.data) {
        const { type, payload } = event.data;

        if (type === 'ENVIAR_MENSAJE' && payload) {
            // Envía el mensaje al background script
            console.log("script event.data ==> ENVIAR_MENSAJE");

            chrome.runtime.sendMessage(event.data);
        }
    }

});

// Escuchar los mensajes enviados desde el popup
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.type === 'RESPUESTA_ENVIAR_MENSAJE' && request.payload) {
        window.postMessage(request, "*");
    }
});