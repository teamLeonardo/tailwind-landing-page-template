// content_script.js

// Escuchar eventos de "message"
window.addEventListener('message', async (event) => {
    // Verificar la fuente del mensaje para mayor seguridad
    if (event.source !== window) return;

    const { type, payload, uid } = event.data;

    // Asegurarse de que el mensaje tenga el formato esperado
    if (type && payload && uid) {
        switch (type) {
            case 'ENVIAR_MENSAJE':
                try {
                    const { number, mensajes, defaultPhone } = payload;
                    console.log("enviarMensaje =  event.data  ===>",  event.data);
                    const timeStart = new Date();
                    for (const mensaje of mensajes) {
                        await enviarMensaje(number, mensaje);
                    }
                    const timeEnd = new Date();
                    window.postMessage(
                        {
                            type: 'RESPUESTA_ENVIAR_MENSAJE',
                            uid,
                            payload: {
                                time: timeEnd - timeStart
                            },
                            number: defaultPhone
                        },
                        '*'
                    );
                } catch (error) {
                    console.error('Error al enviar mensajes:', error);
                    window.postMessage({ type: 'RESPUESTA_ENVIAR_MENSAJE', uid, error: error.message, number: payload.defaultPhone }, '*');
                }
                break;
            default:
                console.warn('Tipo de mensaje no manejado:', type);
        }
    }
});

// , {
//     useTemplateButtons: true, // False for legacy
//     buttons: [
//         {
//             url: 'https://wppconnect.io/',
//             text: 'WPPConnect Site'
//         },
//         {
//             phoneNumber: '+55 11 22334455',
//             text: 'Call me'
//         },
//         {
//             id: 'your custom id 1',
//             text: 'Some text'
//         },
//         {
//             id: 'another id 2',
//             text: 'Another text'
//         }
//     ],
// }
const enviarMensaje = async (number, payload) => {
    if (window.WPP && window.WPP.chat.sendTextMessage) {
        console.log("enviarMensaje ===>", payload);	
        const { type, text, img } = payload;
        let respuesta = null;
        try {
            if (type === 'text') {
                respuesta = await window.WPP.chat.sendTextMessage(number, text);
            } else if (type === 'img') {
                respuesta = await window.WPP.chat.sendFileMessage(number, img);
            } else if (type === 'text-with-img') {
                respuesta = await window.WPP.chat.sendFileMessage(number, img, { caption: text });
            }
        } catch (error) {
            console.error('Error al enviar el mensaje:', error);
            return { error: error.message };
        }
        return respuesta;
    } else {
        console.error('window.WPP o window.WPP.chat.sendTextMessage no están disponibles.');
        return { error: 'WPP o sendTextMessage no disponibles' };
    }
};
