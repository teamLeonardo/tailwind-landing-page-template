(async () => {
    // Inyectar wppconnect-wa.js
    const injectScript = (src) => {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = () => {
                console.log(`${src} cargado correctamente`);
                resolve();
            };
            script.onerror = () => {
                console.error(`Error al cargar ${src}`);
                reject();
            };
            (document.head || document.documentElement).appendChild(script);
        });
    };

    try {
        // Inyectar wppconnect-wa.js
        await injectScript(chrome.runtime.getURL('src/pages/content/wppconnect-wa.js'));

        // Inyectar otroScript.js (por ejemplo)
        await injectScript(chrome.runtime.getURL('src/pages/content/render.js'));

        // Puedes continuar agregando scripts adicionales aquí
    } catch (error) {
        console.error('Error al cargar los scripts:', error);
    }
})();


// Escuchar los mensajes enviados desde el popup
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // Verificar si el tipo de mensaje es 'ENVIAR_MENSAJE' y si hay un payload
    if (request.type === 'ENVIAR_MENSAJE' && request.payload) {
        // Enviar el mensaje a la página web
        window.postMessage(request, "*");
    }
});

 // Escuchar mensajes enviados desde el script insertado en la página web
 window.addEventListener('message', (event) => {
    // Verificar la fuente del mensaje para mayor seguridad
    if (event.source !== window) return;
    // Asegurarse de que el mensaje tenga el formato esperado
    if (event.data && event.data.type === 'RESPUESTA_ENVIAR_MENSAJE') {
        chrome.runtime.sendMessage(event.data)
    }
});