console.log("background.js cargado");

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("request ======>", request);

    // Asegúrate de que el mensaje provenga de localhost:3001 o test-wambot-local.vercel.app
    if (sender.url.startsWith("http://localhost:3001") || sender.url.startsWith("https://test-wambot-local.vercel.app")) {
        
        if (request.type === "ENVIAR_MENSAJE" && request.payload) {
            console.log("request.type && request.payload", request.type, request.payload);
            chrome.tabs.query({ url: '*://web.whatsapp.com/*' }, function (tabs) {
                if (tabs.length > 0) {
                    chrome.tabs.sendMessage(tabs[0].id, request);
                } else {
                    console.error('No se encontró una pestaña de WhatsApp Web abierta.');
                }
            });
            // Permitir que sendResponse sea llamado asincrónicamente
        }

    } else if (sender.url.startsWith("https://web.whatsapp.com")) {
        
        if (request.type === "RESPUESTA_ENVIAR_MENSAJE" && request.payload) {
            console.log("request.type && request.payload", request.type, request.payload);
            // Enviar la respuesta a la página original
            chrome.tabs.query({ url: ['http://localhost:3001/*', 'https://test-wambot-local.vercel.app/*'] }, function (tabs) {
                if (tabs.length > 0) {
                    chrome.tabs.sendMessage(tabs[0].id, request);
                } else {
                    console.error('No se encontró una pestaña de la página original abierta.');
                }
            });
            // Permitir que sendResponse sea llamado asincrónicamente
        }
        
    } else {
        console.error('Mensaje rechazado. El origen no está permitido:', sender.url);
    }
});
